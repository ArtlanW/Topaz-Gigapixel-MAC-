#!/bin/bash
# 恢复原版（英文）界面
cd "$(dirname "$0")" || exit 1
APP="/Applications/Topaz Gigapixel.app"
echo "即将把 Topaz Gigapixel 恢复为官方原版（英文界面）…"
osascript -e 'tell application "Topaz Gigapixel" to quit' 2>/dev/null
sleep 1
sudo /usr/bin/python3 install.py --uninstall --app "$APP"
echo ""
read -p "按回车键关闭窗口…"
