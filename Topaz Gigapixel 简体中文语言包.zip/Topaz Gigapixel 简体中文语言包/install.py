#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Topaz Gigapixel 简体中文语言包安装器（通用版）

原理：
  该应用是 Qt/QML 程序，界面翻译以 QM（Qt 二进制翻译文件）形式编译进可执行文件的
  QRC 资源中，路径为 :/i18n/qml_<lang>.qm。官方只带 de/en/es/fr/ja/pt，没有中文。
  本脚本在可执行文件中定位内嵌的「日语」语言包（ja_JP），以它为模板（其上下文、
  源文本、哈希表必须与新二进制完全一致），把译文替换成中文后写回同一槽位。
  因此官方升级后重新运行本脚本即可，无需重新提取词条。

用法：
  sudo python3 install.py                  # 安装（默认 /Applications/Topaz Gigapixel.app）
  sudo python3 install.py --app "/path/to/Topaz Gigapixel.app"
  python3 install.py --dry-run             # 只检查，不写入
  sudo python3 install.py --uninstall      # 恢复原版二进制（用备份）
"""

import os
import sys
import shutil
import struct
import subprocess
import argparse

MAGIC = bytes([0x3C, 0xB8, 0x64, 0x18, 0xCA, 0xEF, 0x9C, 0x95,
               0xCD, 0x21, 0x1C, 0xBF, 0x60, 0xA1, 0xBD, 0xDD])
HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.expanduser("~/Library/Application Support/TopazGigapixel-zh")
DEFAULT_APP = "/Applications/Topaz Gigapixel.app"


# ---------------------------------------------------------------- 工具
def msg(msg):
    print(msg, flush=True)


def unescape(s):
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c == "\\" and i + 1 < n:
            nx = s[i + 1]
            if nx == "t":
                out.append("\t")
                i += 2
                continue
            if nx == "n":
                out.append("\n")
                i += 2
                continue
            if nx == "\\":
                out.append("\\")
                i += 2
                continue
        out.append(c)
        i += 1
    return "".join(out)


def load_translations(path):
    table = {}
    if not os.path.exists(path):
        sys.exit("找不到翻译表: " + path)
    for ln in open(path, encoding="utf-8").read().split("\n"):
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        if "\t" not in ln:
            continue
        src, dst = ln.split("\t", 1)
        table[unescape(src)] = unescape(dst)
    return table


def set_user_language(lang):
    """写 uiLanguage 到实际用户的偏好域（sudo 下 SUDO_USER 才是真实用户）"""
    user = os.environ.get("SUDO_USER") or os.environ.get("USER")
    if user and os.geteuid() == 0:
        cmd_prefix = ["sudo", "-u", user]
    else:
        cmd_prefix = []
    subprocess.run(cmd_prefix + ["defaults", "write", "com.topazlabs.Topaz Gigapixel",
                                 "uiLanguage", "-string", lang], capture_output=True)
    subprocess.run(cmd_prefix + ["killall", "cfprefsd"], capture_output=True)


# ---------------------------------------------------------------- QM 解析
def find_qm(binary):
    """返回 [(offset, lang, logical_len)]"""
    found = []
    start = -1
    while True:
        start = binary.find(MAGIC, start + 1)
        if start < 0:
            break
        blocks, end = walk_blocks(binary, start)
        info = {t: (l, s) for t, l, s in blocks}
        lang = ""
        if 0xA7 in info:
            l, s = info[0xA7]
            lang = binary[s:s + l].decode("latin1", "replace")
        if blocks:
            found.append((start, lang, end - start))
    return found


def walk_blocks(d, start):
    cur = start + 16
    blocks = []
    total = len(d)
    while cur + 5 <= total:
        tag = d[cur]
        ln = int.from_bytes(d[cur + 1:cur + 5], "big")
        if tag == 0 or ln == 0 or cur + 5 + ln > total:
            break
        blocks.append((tag, ln, cur + 5))
        cur += 5 + ln
        if len(blocks) > 16:
            break
    return blocks, cur


def parse_message(d, start, end):
    cur = start
    trans, src, ctx, cmt = [], None, None, None
    while cur < end:
        tag = d[cur]
        cur += 1
        if tag == 1:
            break
        if tag in (2, 3, 4, 6, 7, 8):
            ln = int.from_bytes(d[cur:cur + 4], "big")
            cur += 4
            if ln > end - cur:
                return dict(ctx=ctx, src=None, cmt=None, trans=[], start=start, end=None)
            raw = d[cur:cur + ln]
            cur += ln
            if tag == 3:
                trans.append(raw.decode("utf-16-be", "replace"))
            elif tag == 2:
                src = raw.decode("utf-16-be", "replace")
            elif tag == 4:
                ctx = raw.decode("utf-16-be", "replace")
            elif tag == 6:
                src = raw.decode("utf-8", "replace").rstrip("\x00")
            elif tag == 7:
                ctx = raw.decode("utf-8", "replace").rstrip("\x00")
            elif tag == 8:
                cmt = raw.decode("utf-8", "replace").rstrip("\x00")
        elif tag == 5:
            cur += 4
        else:
            break
    return dict(ctx=ctx, src=src, cmt=cmt, trans=trans, start=start, end=cur)


def block(tag, payload):
    return bytes([tag]) + struct.pack(">I", len(payload)) + payload


def build_qm(d, slot_start, slot_len, table, keep_comments=True):
    """以槽位内的原语言包为模板，生成中文 QM"""
    blocks, _ = walk_blocks(d, slot_start)
    info = {t: (l, s) for t, l, s in blocks}
    if 0x42 not in info or 0x69 not in info:
        sys.exit("目标语言包结构异常（缺哈希表或消息块）")
    hb, hp = info[0x42]
    mb, mp = info[0x69]
    ctx_block = d[info[0x2F][1]:info[0x2F][1] + info[0x2F][0]] if 0x2F in info else None
    num_block = d[info[0x88][1]:info[0x88][1] + info[0x88][0]] if 0x88 in info else None

    msgs = bytearray()
    entries = []
    stat = dict(hit=0, miss=0, nosrc=0)
    miss_list = []

    for i in range(hb // 8):
        h = int.from_bytes(d[hp + i * 8:hp + i * 8 + 4], "big")
        o = int.from_bytes(d[hp + i * 8 + 4:hp + i * 8 + 8], "big")
        m = parse_message(d, mp + o, mp + mb)
        entries.append((h, len(msgs)))

        if m["src"] is None:
            stat["nosrc"] += 1
            if m["end"] is None:
                if m.get("ctx"):
                    b = m["ctx"].encode("utf-8") + b"\x00"
                    msgs += bytes([7]) + struct.pack(">I", len(b)) + b
                msgs += bytes([6]) + struct.pack(">I", 1) + b"\x00"
                msgs += bytes([3]) + struct.pack(">I", 0)
                msgs += bytes([1])
            else:
                msgs += d[m["start"]:m["end"]]
            continue

        t = table.get(m["src"])
        if t is None:
            stat["miss"] += 1
            if len(miss_list) < 15:
                miss_list.append(m["src"])
            t = m["src"]          # 未翻译的条目回落为英文
        else:
            stat["hit"] += 1

        if m["ctx"] is not None:
            b = m["ctx"].encode("utf-8") + b"\x00"
            msgs += bytes([7]) + struct.pack(">I", len(b)) + b
        if keep_comments and m["cmt"] is not None:
            b = m["cmt"].encode("utf-8") + b"\x00"
            msgs += bytes([8]) + struct.pack(">I", len(b)) + b
        b = m["src"].encode("utf-8") + b"\x00"
        msgs += bytes([6]) + struct.pack(">I", len(b)) + b
        b = t.encode("utf-16-be")
        msgs += bytes([3]) + struct.pack(">I", len(b)) + b
        msgs += bytes([1])

    out = bytearray(MAGIC)
    out += block(0xA7, b"zh_CN")
    if ctx_block:
        out += block(0x2F, ctx_block)
    out += block(0x42, b"".join(struct.pack(">II", h, o) for h, o in entries))
    out += block(0x69, bytes(msgs))
    if num_block:
        out += block(0x88, num_block)
    return bytes(out), stat, miss_list, len(entries)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default=DEFAULT_APP)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--uninstall", action="store_true")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    binary = os.path.join(args.app, "Contents/MacOS/Topaz Gigapixel")
    if not os.path.exists(binary):
        sys.exit("找不到可执行文件: " + binary)

    # ---------------- 卸载 ----------------
    if args.uninstall:
        bak = os.path.join(BACKUP_DIR, "Topaz Gigapixel.orig")
        if not os.path.exists(bak):
            sys.exit("没有找到备份: " + bak)
        shutil.copy2(bak, binary)
        os.chmod(binary, 0o755)
        msg("已恢复原版二进制，重新签名…")
        subprocess.run(["codesign", "--force", "--deep", "--sign", "-", args.app],
                       capture_output=True)
        set_user_language("en")
        msg("完成：界面已恢复英文。")
        return

    d = bytearray(open(binary, "rb").read())
    qms = find_qm(bytes(d))
    if not qms:
        sys.exit("未在可执行文件中找到任何 Qt 语言包，可能不是受支持的版本。")
    msg("检测到 %d 个内嵌语言包：" % len(qms))
    for off, lang, ln in qms:
        msg("   %-10s 偏移=0x%x  长度=%d" % (lang or "?", off, ln))

    cand = [q for q in qms if q[1].lower().startswith("ja")]
    if not cand:
        cand = [q for q in qms if not q[1].lower().startswith("en") and q[2] > 20000]
    if not cand:
        sys.exit("没找到可用于承载中文的语言包槽位。")
    slot_start, lang, slot_len = max(cand, key=lambda x: x[2])
    msg("\n选用槽位: %s @ 0x%x，容量 %d 字节" % (lang, slot_start, slot_len))

    table = load_translations(os.path.join(HERE, "translations.tsv"))
    msg("翻译表条目: %d" % len(table))

    qm, stat, miss, total = build_qm(bytes(d), slot_start, slot_len, table)
    msg("模板消息数: %d，命中译文: %d，未翻译: %d，特殊条目: %d"
        % (total, stat["hit"], stat["miss"], stat["nosrc"]))
    if miss:
        msg("未翻译（将显示英文）示例: " + " | ".join(s[:40] for s in miss[:5]))

    if len(qm) > slot_len:
        msg("⚠️ 语言包 %d 字节超出槽位 %d 字节，尝试精简…" % (len(qm), slot_len))
        qm, stat, miss, total = build_qm(bytes(d), slot_start, slot_len, table,
                                         keep_comments=False)
        msg("精简后: %d 字节" % len(qm))
    if len(qm) > slot_len:
        sys.exit("❌ 仍然超出槽位，无法安全写入。")

    msg("生成中文语言包: %d 字节，槽位剩余 %d 字节" % (len(qm), slot_len - len(qm)))

    if args.out:
        open(args.out, "wb").write(qm)
        msg("已输出: " + args.out)
        if args.dry_run:
            return

    if args.dry_run:
        msg("\n[预演] 未写入任何文件。")
        return

    # ---------------- 备份 ----------------
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ver = "unknown"
    try:
        import plistlib
        with open(os.path.join(args.app, "Contents/Info.plist"), "rb") as f:
            ver = plistlib.load(f).get("CFBundleShortVersionString", "unknown")
    except Exception:
        pass
    bak = os.path.join(BACKUP_DIR, "Topaz Gigapixel.orig")
    if not os.path.exists(bak):
        shutil.copy2(binary, bak)
        msg("已备份原二进制 → %s" % bak)
    else:
        msg("备份已存在（保留首次的原版备份）: %s" % bak)
    open(os.path.join(BACKUP_DIR, "version.txt"), "w").write(str(ver) + "\n")
    open(os.path.join(BACKUP_DIR, "qml_zh_CN.qm"), "wb").write(qm)

    # ---------------- 写入 ----------------
    d[slot_start:slot_start + len(qm)] = qm
    d[slot_start + len(qm):slot_start + slot_len] = b"\x00" * (slot_len - len(qm))
    open(binary, "wb").write(d)
    os.chmod(binary, 0o755)
    msg("已写入中文语言包（含零填充）")

    # 复核
    chk = open(binary, "rb").read()
    if chk.find(qm[:64], slot_start) == slot_start:
        msg("✅ 写入校验通过")
    else:
        sys.exit("❌ 写入校验失败")

    # ---------------- 签名与语言 ----------------
    msg("重新签名（ad-hoc）…")
    r = subprocess.run(["codesign", "--force", "--deep", "--sign", "-", args.app],
                       capture_output=True, text=True)
    if r.returncode != 0:
        msg("签名警告: " + (r.stderr or "").strip()[:200])
    else:
        msg("✅ 签名完成")

    set_user_language("ja")
    msg("已设置界面语言为简体中文")


if __name__ == "__main__":
    main()
