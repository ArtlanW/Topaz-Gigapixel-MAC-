#!/bin/bash
# Topaz Gigapixel 简体中文语言包 —— 一键安装
# 双击本文件，在终端里输入一次开机密码即可。

cd "$(dirname "$0")" || exit 1
APP="/Applications/Topaz Gigapixel.app"

echo "=============================================="
echo "  Topaz Gigapixel 简体中文语言包 安装器"
echo "=============================================="

if [ ! -d "$APP" ]; then
    echo "❌ 未找到 $APP"
    echo "   如果装在别的位置，请把本文件夹放到应用旁边并用下面命令安装："
    echo '   sudo /usr/bin/python3 install.py --app "/path/to/Topaz Gigapixel.app"'
    read -p "按回车键关闭窗口…"
    exit 1
fi

echo "即将关闭正在运行的 Topaz Gigapixel 并安装中文语言包…"
osascript -e 'tell application "Topaz Gigapixel" to quit' 2>/dev/null
sleep 1

sudo /usr/bin/python3 install.py --app "$APP"
RC=$?

if [ $RC -eq 0 ]; then
    echo ""
    echo "✅ 安装完成，正在启动应用…"
    sleep 1
    open -a "$APP"
else
    echo ""
    echo "❌ 安装失败（退出码 $RC），未做任何更改。"
fi
echo ""
read -p "按回车键关闭窗口…"
